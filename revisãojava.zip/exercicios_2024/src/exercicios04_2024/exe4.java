package exercicios04_2024;

import java.util.Scanner;

public class exe4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int [] nums = new int[40];
			int [] pos = new int[40];
Scanner scanner = new Scanner (System.in);
			

			for (int i=0; i < 40; i++) {
				System.out.println("digite um número: ");
				nums [i] = scanner.nextInt();
				
			}
			
			for (int i=0; i < 40; i++) {
				for (int j=0; j < 40; j++) {
					if(nums[i] == nums[j] && i!=j) {
						pos[i] = 1;
					}
				}
			}
			for(int i = 0;i<40;i++) {
				if(pos[i]==1) {
					System.out.println("O número repetido "+nums[i]+" está presente nas posições: ");
					for(int j = 0; j<40;j++) {
						if(nums[i] == nums[j]) {
							
							System.out.println((j+1)+"º");
							pos[j]=0;

						}
					}
				}
			}
			
	}

}
