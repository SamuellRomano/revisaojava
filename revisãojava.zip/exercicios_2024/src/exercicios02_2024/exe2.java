package exercicios02_2024;

import java.util.Scanner;

public class exe2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner scanner = new Scanner (System.in);
		int horas, min, seg, conversao, dia;
		
		System.out.println("insira as horas: ");
		horas = scanner.nextInt();
		
		System.out.println("insira os minutos: ");
		min = scanner.nextInt();
		
		System.out.println("insira os segundos: ");
		seg = scanner.nextInt();
		
		conversao = (horas * 3600) + (min * 60) + seg;
		
		
		System.out.println("isso converte à " + conversao+ " segundos");
		
		dia = 86400 - conversao;
		
		horas = dia/3600;
		dia -= horas*3600;
		min = dia/60;
		dia -= min*60;
		seg = dia;
		
		System.out.println("Faltam "+ horas+ " horas, " + min+ " minutos e " + seg + " segundos para 12:00pm"); 
			
		scanner.close();
		
		
}
}