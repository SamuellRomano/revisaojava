package exercicios01_2024;

import java.util.Scanner;

public class exe1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	

	Scanner entrada = new Scanner(System.in);
	
	
	String usu;
	String senha;
	
	
	System.out.println("digite o usuário");
	usu = entrada.next();

	System.out.println("digite a senha");
	senha = entrada.next();
	
	if(!"SENAI".equals(usu)) {
		System.out.println("usuário invalido");
	}

	if(!"1000GRAU".equals(senha)) {
		System.out.println("senha invalida");
	}
	if("SENAI".equals(usu) && "1000GRAU".equals(senha)) {
		System.out.println("Bem-Vindo(a)");
		
	}
}
}
