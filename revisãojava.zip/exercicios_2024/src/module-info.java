/**
 * 
 */
/**
 * @author Pedro Henrique Mêna
 *
 */
module exercicio1_2024 {
}