package exercicios03_2024;

import java.util.Scanner;

public class exe3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner (System.in);
		
		double carro, conce, impos;
		
		System.out.println("digite o valor bruto do carro: ");
		carro = scanner.nextDouble();
		
		conce = 0.32 * carro;
		
		impos = 0.63 * carro;
		
		System.out.println("o valor do carro será: "+(carro+ conce+ impos)+"R$");
		
		scanner.close();
	
	}

}
